package models;

import org.hibernate.Query;
import org.hibernate.Session;
import utils.HibernateSessionFactoryUtil;

import javax.jws.soap.SOAPBinding;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class UserManager  extends User{
    public void Delete(User user)
    {
        Session session= HibernateSessionFactoryUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.delete(user);
        System.out.println("Deleted successfully");
        session.getTransaction().commit();
        session.close();
    }
    public void Update(int id)
    {
        Scanner in=new Scanner(System.in);
        System.out.printf("Enter new name: ");
        String newName=in.next();
        Session session= HibernateSessionFactoryUtil.getSessionFactory().openSession();
        session.beginTransaction();
        User user1 = (User) session.get(User.class, id);
        user1.setName(newName);
        session.update(user1);
        System.out.println("Updated successfully");
        session.getTransaction().commit();
        session.close();
    }
    public void Create()
    {
        Scanner in=new Scanner(System.in);
        System.out.printf("Enter new name: ");
        String newName=in.next();
        User user=new User();
        user.setName(newName);
        Session session= HibernateSessionFactoryUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(user);
        System.out.println("Inserted successfully");
        session.getTransaction().commit();
        session.close();
    }

    public void Read() {

        Session session= HibernateSessionFactoryUtil.getSessionFactory().openSession();
        session.beginTransaction();
        List users=session.createQuery("FROM User ").list();
        for (Iterator iterator1 = users.iterator(); iterator1.hasNext();) {
            User user = (User) iterator1.next();
            System.out.println("Name: " + user.getName());
            System.out.println("ID: " + user.getId());

        }
        session.getTransaction().commit();
        session.close();

    }



}
