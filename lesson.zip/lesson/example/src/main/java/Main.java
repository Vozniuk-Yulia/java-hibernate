import models.User;
import models.UserManager;
import org.hibernate.Session;
import utils.HibernateSessionFactoryUtil;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        Session session= HibernateSessionFactoryUtil.getSessionFactory().openSession();
        session.beginTransaction();

//        //Add new Employee object


//
//
//        //Save the employee in database
//        session.save(user);
//
        UserManager userManager=new UserManager();

        //userManager.Update(2);
        userManager.Read();


        //Commit the transaction
        session.getTransaction().commit();
        session.close();
    }
}
